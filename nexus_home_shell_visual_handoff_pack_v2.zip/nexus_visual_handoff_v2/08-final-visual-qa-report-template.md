# 08 — Final MLLM Visual QA Report Template

Use this after the code LLM applies S-8/S-10.

## A. Visual state summary

- Home empty state:
- Home active chat:
- Workspace route:
- Import modal/action:
- Insufficient credits state:

## B. Home shell readiness

Verdict: PASS / PARTIAL / FAIL

Evidence from screenshot/browser:

- `/` is Home, not NexusOps:
- Composer hierarchy:
- Sidebar clarity:
- Recent chats:
- Workspace entry:
- Wallet visibility:
- Model selector clarity:

## C. Workspace navigation readiness

Verdict: PASS / PARTIAL / FAIL

Evidence:

- NexusOps preserved:
- Back-to-Home visible:
- Workspace identity visible:
- Tabs/nav clarity:

## D. Wallet/credits UX readiness

Verdict: PASS / PARTIAL / FAIL

Evidence:

- Balance visible:
- Estimate visible:
- Insufficient credits clear:

## E. Blocking UI issues

Numbered list.

## F. Non-blocking polish issues

Numbered list.

## G. Fix list for code agent

Actionable, file-oriented.

## H. Readiness verdict

S-8: READY / PARTIAL / BLOCKED
S-10: READY / PARTIAL / BLOCKED
