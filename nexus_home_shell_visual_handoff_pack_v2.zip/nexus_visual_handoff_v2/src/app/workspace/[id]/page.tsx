import { WorkspaceTopNav } from '@/components/workspace/WorkspaceTopNav';
import '@/styles/nexus-home.css';

// Replace this with the actual NexusOps import path discovered in repo.
// import { NexusOps } from '@/components/nexus-ops/NexusOps';

type WorkspacePageProps = {
  params: { id: string };
};

export default function WorkspacePage({ params }: WorkspacePageProps) {
  return (
    <main className="nexus-workspace-shell">
      <WorkspaceTopNav workspaceName={params.id} />
      <section className="nexus-workspace-body">
        {/* <NexusOps workspaceId={params.id} /> */}
        <div className="nexus-workspace-placeholder">
          <p>Mount existing NexusOps here. Do not delete NexusOps.</p>
          <h1>Workspace {params.id}</h1>
          <p>This wrapper is only for S-10 navigation simplification.</p>
        </div>
      </section>
    </main>
  );
}
