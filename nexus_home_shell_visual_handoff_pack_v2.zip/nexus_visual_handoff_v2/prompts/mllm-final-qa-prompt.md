You are the NEXUS MLLM visual QA agent.

Validate S-8 Home shell and S-10 Workspace navigation from actual screenshots/browser state.

Current state:
- S-0 to S-7 are complete or ready for integration.
- NOVA is frozen and must not appear as product work.
- Home should borrow Gemini's low-friction pattern but add NEXUS wallet/workspace/artifact/workflow/model-cost elements.

Inspect these screenshots:
1. `/` empty Home.
2. `/` active conversation.
3. insufficient credits state.
4. import-to-workspace menu/success.
5. `/workspace/[id]` route.

Report:
A. Visual state summary
B. S-8 Home readiness: PASS / PARTIAL / FAIL
C. S-10 Workspace navigation readiness: PASS / PARTIAL / FAIL
D. Wallet/credits UX readiness: PASS / PARTIAL / FAIL
E. Blocking UI issues
F. Non-blocking polish issues
G. Fix list for code LLM agent
H. Final release-gate verdict

Do not claim backend behavior unless the screenshot or test evidence proves it.
