import {
  GlobalConversation,
  GlobalMessage,
  ImportToWorkspaceInput,
  ImportToWorkspaceResult,
  InsufficientCreditsError,
  NexusModel,
  SendGlobalMessageInput,
  SendGlobalMessageResult,
  WalletBalance,
  WorkspaceShortcut,
} from './types';

async function requestJson<T>(path: string, init?: RequestInit): Promise<T> {
  const response = await fetch(path, {
    ...init,
    headers: {
      'content-type': 'application/json',
      ...(init?.headers ?? {}),
    },
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : null;

  if (response.status === 402) {
    throw new InsufficientCreditsError(data ?? {});
  }

  if (!response.ok) {
    throw new Error(data?.error ?? data?.message ?? `Request failed: ${response.status}`);
  }

  return data as T;
}

/**
 * Adapter note:
 * These defaults must be mapped to the actual routes discovered by the S-7/S-8 code agent.
 * Keep route naming edits inside this file so visual components stay stable.
 */
export const nexusHomeApi = {
  listGlobalConversations(): Promise<GlobalConversation[]> {
    return requestJson<GlobalConversation[]>('/api/global-conversations');
  },

  createGlobalConversation(input?: { title?: string }): Promise<GlobalConversation> {
    return requestJson<GlobalConversation>('/api/global-conversations', {
      method: 'POST',
      body: JSON.stringify(input ?? {}),
    });
  },

  listGlobalMessages(conversationId: string): Promise<GlobalMessage[]> {
    return requestJson<GlobalMessage[]>(`/api/global-conversations/${conversationId}/messages`);
  },

  sendGlobalMessage(input: SendGlobalMessageInput): Promise<SendGlobalMessageResult> {
    const conversationId = input.conversationId ?? 'new';
    return requestJson<SendGlobalMessageResult>(`/api/global-conversations/${conversationId}/messages`, {
      method: 'POST',
      body: JSON.stringify({ content: input.content, modelId: input.modelId }),
    });
  },

  getWalletBalance(): Promise<WalletBalance> {
    return requestJson<WalletBalance>('/api/wallet/balance');
  },

  listModels(): Promise<NexusModel[]> {
    return requestJson<NexusModel[]>('/api/models');
  },

  listWorkspaces(): Promise<WorkspaceShortcut[]> {
    return requestJson<WorkspaceShortcut[]>('/api/workspaces');
  },

  importToWorkspace(input: ImportToWorkspaceInput): Promise<ImportToWorkspaceResult> {
    return requestJson<ImportToWorkspaceResult>(`/api/workspaces/${input.workspaceId}/imports`, {
      method: 'POST',
      body: JSON.stringify(input),
    });
  },
};
