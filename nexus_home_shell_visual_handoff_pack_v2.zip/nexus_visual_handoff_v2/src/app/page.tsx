import { NexusHomeShell } from '@/components/nexus-home/NexusHomeShell';
import '@/styles/nexus-home.css';

export default function HomePage() {
  return <NexusHomeShell />;
}
