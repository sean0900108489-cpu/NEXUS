# 03 — S-7 Import Bridge Contract

S-7 import-to-workspace must connect visually to the Home shell.

## Product contract

A user starts in global chat. When an answer becomes useful, they can copy it into a workspace.

Import must be copy-only:

- global conversation remains intact,
- workspace receives a separate copy,
- imported item keeps provenance back to source conversation/message,
- deleting global chat should not delete workspace copy,
- deleting workspace copy should not delete global original.

## UI entry points

Home should expose import in three places:

1. Intent chip: `Import to workspace` or `Open workspace`.
2. Assistant message action: `Import to Workspace`.
3. Conversation overflow menu: `Move a copy into workspace`.

## Import modal/dropdown

Fields:

- Target workspace.
- Import type: `artifact`, `note`, `task`, or `context bundle` depending on what S-7 supports.
- Optional title.
- Optional note.

Primary CTA:

`Import copy`

Success state:

`Imported to {workspaceName}` with CTA `Open workspace`.

Failure state:

Do not lose source message. Show retry and copy fallback.

## Handoff requirement to S-7 LLM

The S-7 LLM should provide exact route, input payload, and response shape. If not known, the Home code agent uses the adapter defaults in `src/lib/nexus-home/api.ts` and marks mismatches.
