# 06 — Code Agent Integration Order

Give this order to the LLM agent that just finished S-7.

## Step 1 — Discover actual routes

Search repo for:

- global conversation routes,
- workspace import route from S-7,
- wallet balance route,
- model catalog route,
- NexusOps component path.

## Step 2 — Add adapter layer

Add `src/lib/nexus-home/api.ts` and `types.ts` or map to existing repo services.

The visual components should call the adapter only.

## Step 3 — Add Home components

Add or adapt:

- `NexusHomeClient`
- `NexusHomeShell`
- `NexusSidebar`
- `NexusChatCanvas`
- `NexusPromptComposer`
- `NexusWorkspaceImportMenu`
- `NexusInsufficientCreditsDialog`

## Step 4 — Route `/`

`src/app/page.tsx` renders Home.

Do not mount NexusOps at `/` anymore.

## Step 5 — Route `/workspace/[id]`

Keep existing NexusOps inside a workspace layout/top nav.

## Step 6 — Wire S-7 import

Message action `Import to Workspace` calls S-7 route through `importToWorkspace(...)`.

## Step 7 — Validate

Run typecheck/tests.

Then capture screenshots for MLLM QA:

- `/` empty state,
- `/` active chat,
- insufficient credits,
- import modal,
- `/workspace/[id]`.
