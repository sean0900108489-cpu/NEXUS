You are the code LLM agent taking over after S-7.

Use `nexus_home_shell_visual_handoff_pack_v2` as the visual and integration handoff.

Your task:
1. Discover actual S-6 global conversation routes and S-7 import-to-workspace route.
2. Map them in `src/lib/nexus-home/api.ts`.
3. Implement S-8 Home shell route at `/`.
4. Preserve NexusOps under `/workspace/[id]`.
5. Add the S-10 workspace top nav wrapper without rewriting NexusOps internals.
6. Run typecheck/tests.
7. Provide screenshots for MLLM QA.

Constraints:
- No Supabase migration.
- No deploy.
- No NOVA product work.
- No destructive database changes.
- No secrets output.
- No visual QA claim without MLLM.

Expected output:
A. Files changed
B. Actual API routes discovered
C. Adapter mapping used
D. S-7 import connection details
E. Typecheck/test result
F. Screenshots needed
G. Remaining gaps
