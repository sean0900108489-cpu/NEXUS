# NEXUS Home Shell Visual Handoff Pack v2

This pack is the MLLM-facing visual and integration handoff for the agent that just completed S-7.

Current state assumed:
- S-0 authority repair complete.
- S-1 vocabulary rename complete.
- S-2 wallet types/migration complete.
- S-3 wallet balance gate complete.
- S-4 pricing metadata partial.
- S-5 grant + deduction flow complete.
- S-6 global conversations domain complete.
- S-7 import-to-workspace contract complete or ready for integration.
- NOVA remains frozen; do not surface NOVA as product work.

This pack handles:
- Visual direction for S-8 Home shell entry route.
- Visual and navigation direction for S-10 Workspace navigation simplification.
- UI integration points to S-6 global chat, S-5 wallet credits, S-7 import-to-workspace, and S-9 catalog alignment.
- Concrete code scaffolds and adapter contracts for the code LLM agent.
- QA acceptance criteria for MLLM visual validation.

This pack does not:
- Modify Supabase.
- Add migrations.
- Deploy.
- Touch NOVA product features.
- Claim backend correctness without API/test evidence.

Primary implementation handoff:
1. Apply or adapt `src/app/page.tsx` to route `/` to Home / Global Chat.
2. Keep NexusOps under `/workspace/[id]` and add a simpler workspace top nav.
3. Wire Home through the adapters in `src/lib/nexus-home/api.ts`.
4. Use S-7 import endpoint through `importToWorkspace(...)`.
5. Run typecheck/tests.
6. Capture screenshots for MLLM visual QA using `qa/visual-acceptance-checklist.md`.
