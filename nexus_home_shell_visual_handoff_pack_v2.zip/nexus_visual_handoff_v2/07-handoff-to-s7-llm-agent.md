# 07 — Handoff to the LLM Agent That Finished S-7

You just finished S-7 import-to-workspace contract. Now integrate it visually into S-8 Home and prepare S-10 Workspace navigation.

## Current visual decision

NEXUS Home should borrow Gemini's low-friction layout pattern:

- left sidebar,
- central empty state,
- dominant composer,
- recent chats,
- model selector.

But NEXUS must add:

- wallet credits,
- workspace transition,
- artifact/workflow intent,
- model cost awareness,
- import-to-workspace actions.

## Your next implementation task

Implement S-8 Home shell using this pack as scaffolding.

Specifically:

1. Replace `/` old NexusOps root with Home / Global Chat shell.
2. Keep NexusOps under `/workspace/[id]`.
3. Use adapter layer to connect S-6 global conversations and S-7 import contract.
4. Surface wallet credits and model selection.
5. Add import-to-workspace UI action on assistant messages.
6. Add workspace top nav wrapper for S-10, but do not rewrite NexusOps internals.

## Hard restrictions

- No Supabase migration.
- No deploy.
- No destructive database changes.
- No NOVA product work.
- No visual QA claim after code only; MLLM must inspect screenshots.

## Output expected from you

A. Exact files changed
B. Actual API routes discovered
C. Adapter mapping used
D. How S-7 import is connected
E. Typecheck/test result
F. Screenshots needed for MLLM
G. Remaining integration gaps
