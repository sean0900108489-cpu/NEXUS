# 02 — S-8 Interfaces and API Adapters

This is the key bridge for the code LLM agent.

The UI should not hard-code backend assumptions everywhere. Use a thin adapter layer so S-6/S-7 route names can be corrected in one place.

## Required UI data

Home needs:

- current wallet balance,
- model catalog / selected model,
- recent global conversations,
- active conversation messages,
- workspaces list,
- import-to-workspace action,
- insufficient credits error payload.

## Adapter contract

Create or adapt a file like:

`src/lib/nexus-home/api.ts`

Required functions:

- `listGlobalConversations()`
- `createGlobalConversation(input)`
- `listGlobalMessages(conversationId)`
- `sendGlobalMessage(input)`
- `getWalletBalance()`
- `listModels()`
- `listWorkspaces()`
- `importToWorkspace(input)`

## Expected backend routes

Use actual repo routes if they differ. These are the visual pack defaults:

- `GET /api/global-conversations`
- `POST /api/global-conversations`
- `GET /api/global-conversations/:conversationId/messages`
- `POST /api/global-conversations/:conversationId/messages`
- `GET /api/wallet/balance`
- `GET /api/models`
- `GET /api/workspaces`
- `POST /api/workspaces/:workspaceId/imports`

If S-7 created a different import route, map it inside the adapter only.

## Important

Do not block S-8 on perfect backend route naming. The code agent should wire to actual routes discovered in repo. If a route does not exist, add a placeholder TODO and report it as integration gap, not visual failure.
