# 05 — State Machine and Error UX

## Home states

1. Loading
   - Skeleton sidebar and composer.
   - No raw spinners covering the whole app.

2. Empty
   - NEXUS hero and composer.
   - Recent chats visible.
   - Wallet visible.

3. Active conversation
   - Message list.
   - Composer docked lower center/bottom.
   - Assistant message actions visible on hover/focus.

4. Streaming
   - Send disabled or transformed into stop button.
   - Cost estimate remains visible.

5. Insufficient credits
   - Prompt preserved.
   - Clear actions: Add credits, choose cheaper model, view usage.

6. Import success
   - Toast or inline message.
   - CTA to open target workspace.

7. Import failure
   - Retry.
   - Keep source message and selected workspace intact.

## Error copy rules

Do not expose raw internal names:

- Avoid `QUOTA_EXCEEDED`.
- Avoid transaction IDs.
- Avoid route stack traces.
- Avoid provider secrets/channel names.

Use user-facing concepts:

- credits,
- selected model,
- workspace,
- retry,
- lower-cost model.
