# Visual Acceptance Checklist

## S-8 Home shell

- [ ] `/` does not open old NexusOps as the first surface.
- [ ] Home has a calm central AI entry surface.
- [ ] Prompt composer is the dominant action.
- [ ] Sidebar is useful but not dense.
- [ ] Recent chats are scannable.
- [ ] Workspaces are visible and clearly separate from recent chats.
- [ ] Wallet credits are visible in sidebar.
- [ ] Model selector is visible near composer.
- [ ] Estimated credits are visible near model selector.
- [ ] NOVA is not shown as product work.

## Active global chat

- [ ] Empty hero collapses after messages begin.
- [ ] Message list is readable.
- [ ] Assistant message actions include import-to-workspace.
- [ ] Import modal/dropdown is understandable.
- [ ] Success state links to workspace.

## Wallet UX

- [ ] Low/empty wallet states are visually distinct.
- [ ] Insufficient credits dialog does not show raw 402.
- [ ] Prompt is preserved after insufficient credits.
- [ ] Cheaper model path is available if backend provides alternatives.

## S-10 Workspace navigation

- [ ] `/workspace/[id]` clearly says workspace.
- [ ] Existing NexusOps is preserved inside workspace route.
- [ ] Back-to-Home is visible.
- [ ] Tabs are simple: Chat, Artifacts, Workflows, Tools, Settings.
- [ ] Workspace nav does not contain NOVA.
- [ ] Workspace does not visually look identical to Home.
