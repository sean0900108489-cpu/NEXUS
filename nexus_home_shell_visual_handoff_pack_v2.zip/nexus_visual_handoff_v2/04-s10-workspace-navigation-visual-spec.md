# 04 — S-10 Workspace Navigation Visual Spec

S-10 is not a full NexusOps rewrite. It is navigation simplification.

## Goal

When the user opens `/workspace/[id]`, they should understand:

- they are no longer in global Home chat,
- this is a work container,
- NexusOps is preserved,
- there is a clear path back to Home.

## Required top nav

Add a workspace top bar around existing NexusOps:

- Back to Home.
- Workspace name.
- Section tabs: Chat, Artifacts, Workflows, Tools, Settings.
- Wallet mini-badge, optional.

## Visual separation

Home should be calm and broad.

Workspace should feel more structured and operational.

Avoid copying Home's empty state into Workspace. Workspace is where work is managed.

## Do not

- Delete NexusOps.
- Hide core NexusOps functionality.
- Put NOVA in nav.
- Mix global recent chats with workspace-specific conversation history unless clearly labeled.

## Readiness criteria

S-10 is visually ready when:

- Workspace route has a clear identity.
- Back-to-Home is visible.
- Old NexusOps does not appear as the root product surface.
- Workspace nav is legible and less confusing than the old root.
