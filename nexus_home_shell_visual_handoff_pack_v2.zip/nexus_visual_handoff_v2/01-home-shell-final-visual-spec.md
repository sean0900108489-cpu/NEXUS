# 01 — Home Shell Final Visual Spec

## Route ownership

`/` = NEXUS Home / Account-level Global Chat.

`/workspace/[id]` = Workspace OS / NexusOps container. NexusOps is not deleted.

## Layout

Desktop layout:

- 288–304px left sidebar.
- Full-height main canvas.
- Top-right status row with model/wallet/account shortcuts, kept light.
- Centered empty state with NEXUS identity and a large composer.
- Background should be soft, calm, and slightly luminous, not a heavy dashboard.

Responsive layout:

- At tablet/mobile width, sidebar collapses into top/slide navigation.
- Composer remains the dominant action.
- Wallet and model info must remain reachable.

## Left sidebar content order

1. NEXUS brand mark.
2. New Chat.
3. Search Chats.
4. Workspaces.
5. Artifacts.
6. Workflows.
7. Recent Chats.
8. Workspace shortcuts.
9. Wallet credits.
10. User profile/settings.

Do not add NOVA.

## Main empty state

Recommended hierarchy:

- Kicker: `AI Agent Workspace / Agent OS`
- Main: `Build, reason, and ship with NEXUS.`
- Body: `Start in global chat. Move real work into a workspace as an artifact, workflow, or agent task.`
- Intent chips:
  - Draft strategy
  - Analyze files
  - Create artifact
  - Plan workflow
  - Import to workspace

## Composer

Required affordances:

- Attach.
- Text input.
- Model selector.
- Estimated credits.
- Send.
- Optional tool/workflow toggle.

Recommended placeholder:

`Ask NEXUS to reason, build, or move work into a workspace…`

## Chat state

After first user message, the center empty state should collapse into a conversation canvas.

Message actions on assistant outputs:

- Copy.
- Create artifact.
- Import to workspace.
- Start workflow, if runtime is ready; otherwise show as disabled/coming soon.

## Wallet surface

Wallet is visible but calm:

- Sidebar badge: `12,450 credits`.
- Composer estimate: `Est. 8–14 credits`.
- Low state: amber dot and `Low credits`.
- Empty state: red dot and `Add credits`.

## Insufficient credits state

Do not show raw `402` or internal transaction text.

Show:

Title: `Not enough credits for this run.`
Body: `This model needs about {requiredCredits} credits, but your wallet has {currentBalance}. Add credits or switch to a lower-cost model.`
Actions: `Add credits`, `Choose cheaper model`, `View usage`.

Keep the user's prompt intact.
