# 00 — MLLM Visual Decision Report

## Reference observed

The uploaded Gemini Home reference uses a low-friction AI entry pattern:

- Left rail: brand, new chat, search, media/notebook entries, recent conversations, user control.
- Main canvas: almost empty, centered headline, one dominant prompt composer.
- Composer: attach button, input, model selector, voice/send controls.
- Tone: calm, spacious, minimal dashboard noise.

## What NEXUS should borrow

NEXUS should borrow the product structure, not the branding:

- A calm Home surface at `/`.
- A readable left sidebar with new chat, search, recent chats, workspaces, wallet, user.
- A single dominant central composer.
- Model selector near the composer.
- Empty state that makes the first action obvious.

## What NEXUS must add

NEXUS is not a generic chat clone. It needs its own commercial Agent OS layer:

- Wallet credits visible in the sidebar and composer estimate.
- Workspace transition visible but not forced.
- Artifact and workflow intent chips.
- Import-to-workspace action after useful global chat output.
- Model cost awareness.
- Clear separation between Home / Global Chat and Workspace OS.

## Visual decision

S-8 should implement a Gemini-like low-friction shell with NEXUS-specific Agent OS controls.

The default `/` should feel like:

> Start here, reason here, then move serious work into a workspace.

It should not feel like:

> A developer dashboard, a database console, or the old NexusOps root.

## MLLM verdict

S-8 and S-10 now require visual QA. Pure LLM can implement adapters and code scaffolds, but MLLM must validate screenshots for:

- visual clarity,
- layout hierarchy,
- sidebar density,
- model/wallet affordance,
- workspace navigation separation,
- insufficient credits UX.
